library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader( title = "Encabezado"),
  dashboardSidebar(),
  dashboardBody()
)

server <- function(input, output){}

shinyApp (ui = ui, server = server)