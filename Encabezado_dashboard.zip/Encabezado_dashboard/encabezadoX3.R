library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader( title = "Encabezado",
                   
    dropdownMenu( type = "messages",
                  messageItem(
                    from = "Depto. Ventas",
                      message = "Ventas estables este mes"
                    ),
                  messageItem(
                    from ="Nuevo Usuario",
                    message = "¿Cómo me registro?",
                    icon = icon("question"),
                    time = "19:30"
                    ),
                  messageItem(
                    from = "Soporte",
                    message = "El nuevo servidor está listo.",
                    icon = icon("life-ring"),
                    time = "13-11-2020"
                  )
                ),
    
    dropdownMenu(type = "notifications",
                 notificationItem(
                   text = "5 nuevos usuarios",
                   icon("users")
                 ),
                 notificationItem(
                   text = "12 ítems despachados",
                   icon("truck"),
                   status = "success"
                 ),
                 notificationItem(
                   text = "Servidor cargado al 86%",
                   icon = icon("exclamation-triangle"),
                   status = "warning"
                 )
                ),
    dropdownMenu(type = "tasks",
                 badgeStatus = "success",
                 taskItem(value = 90, color = "green",
                           "Documentación"
                           ),
                 taskItem(value = 17, color = "aqua",                
                          "Proyecto X"
                          ),
                 
                 taskItem(value = 75, color = "yellow",                
                          "Despliegue del servidor"
                 ),

                 taskItem(value = 80, color = "red",                
                          "Proyecto general"
                 )
    )
    ),
  dashboardSidebar(),
  dashboardBody()
)

server <- function(input, output){}

shinyApp (ui = ui, server = server)