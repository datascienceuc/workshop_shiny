library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Barra Lateral"),
  dashboardSidebar(
    sidebarSearchForm(textId = "searchText",
                      buttonId = "searchButton",
                      label = "Búsqueda")
  ),
  dashboardBody()
)

server <- function(input, output){}

shinyApp (ui = ui, server = server)