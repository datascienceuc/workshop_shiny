library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Barra Lateral"),
  dashboardSidebar(),
  dashboardBody(
    tabBox(
      side = "right" , height = "250px", 
      selected = "Tab3",
      tabPanel("Tab1", "Bienvenidos a ..."),
      tabPanel("Tab2", "Contenidos pestaña 2"),
      tabPanel("Tab3", "Contenidos pestaña 3")
    )
  )
)



server <- function(input, output){ }

shinyApp (ui = ui, server = server)