library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Barra Lateral"),
  dashboardSidebar(),
  dashboardBody(
    tabBox(
      title = "Primer cuadro de pestañas",
      id = "tabset1", height = "250px", 
      tabPanel("Tab1", "Bienvenidos a ..."),
      tabPanel("Tab2", "Contenidos")
    )
  )
)


server <- function(input, output){ }

shinyApp (ui = ui, server = server)